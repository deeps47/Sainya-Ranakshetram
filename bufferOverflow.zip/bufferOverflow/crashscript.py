python3 -c "print('1' * 11) " | ./question
